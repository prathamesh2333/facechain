"""Central configuration. Everything is overridable through a .env file."""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")

# --- paths -----------------------------------------------------------------
MODELS_DIR = ROOT / "models"
DATA_DIR = ROOT / "data"
EVIDENCE_DIR = DATA_DIR / "evidence"
FACES_DIR = DATA_DIR / "faces"
BUILD_DIR = ROOT / "build"
SAMPLES_DIR = ROOT / "samples"

for _d in (DATA_DIR, EVIDENCE_DIR, FACES_DIR, BUILD_DIR, MODELS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

DEPLOYMENTS_FILE = BUILD_DIR / "deployments.json"
CONTRACT_ARTIFACT = BUILD_DIR / "FaceRegistry.json"
CONTRACT_SOURCE = ROOT / "contracts" / "FaceRegistry.sol"
LOCAL_DB_FILE = FACES_DIR / "index.json"

# --- face models -----------------------------------------------------------
YUNET_PATH = MODELS_DIR / "yunet.onnx"
SFACE_PATH = MODELS_DIR / "sface.onnx"

YUNET_URL = (
    "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/"
    "models/face_detection_yunet/face_detection_yunet_2023mar.onnx"
)
SFACE_URL = (
    "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/"
    "models/face_recognition_sface/face_recognition_sface_2021dec.onnx"
)

# SFace's published operating point for cosine similarity.
MATCH_THRESHOLD = float(os.getenv("MATCH_THRESHOLD", "0.363"))
# Slightly stricter bar before we call a *web* result a confirmed identity.
WEB_MATCH_THRESHOLD = float(os.getenv("WEB_MATCH_THRESHOLD", "0.40"))
DETECT_SCORE_THRESHOLD = float(os.getenv("DETECT_SCORE_THRESHOLD", "0.7"))

# --- search ----------------------------------------------------------------
SERPAPI_KEY = os.getenv("SERPAPI_KEY", "").strip()
SEARCH_MAX_CANDIDATES = int(os.getenv("SEARCH_MAX_CANDIDATES", "25"))
SEARCH_TIMEOUT = int(os.getenv("SEARCH_TIMEOUT", "30"))
USER_AGENT = os.getenv(
    "USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0 Safari/537.36",
)

SOCIAL_DOMAINS = {
    "instagram.com": "instagram",
    "facebook.com": "facebook",
    "fb.com": "facebook",
    "twitter.com": "x",
    "x.com": "x",
    "linkedin.com": "linkedin",
    "youtube.com": "youtube",
    "tiktok.com": "tiktok",
    "pinterest.com": "pinterest",
    "reddit.com": "reddit",
    "threads.net": "threads",
    "threads.com": "threads",
    "vk.com": "vk",
    "flickr.com": "flickr",
    "tumblr.com": "tumblr",
    "imdb.com": "imdb",
    "wikipedia.org": "wikipedia",
    "wikimedia.org": "wikimedia",
    "github.com": "github",
    "medium.com": "medium",
}

# --- blockchain ------------------------------------------------------------
# memory  : in-process EVM (eth-tester). Zero setup, resets each run.
# local   : JSON-RPC node on your machine (Hardhat / Anvil / Ganache). Persistent.
# testnet : public testnet (Polygon Amoy, Sepolia, ...). Real explorer links.
CHAIN_MODE = os.getenv("CHAIN_MODE", "memory").strip().lower()
RPC_URL = os.getenv("RPC_URL", "http://127.0.0.1:8545").strip()
TESTNET_RPC_URL = os.getenv("TESTNET_RPC_URL", "https://rpc-amoy.polygon.technology").strip()
PRIVATE_KEY = os.getenv("PRIVATE_KEY", "").strip()
EXPLORER_TX_URL = os.getenv("EXPLORER_TX_URL", "https://amoy.polygonscan.com/tx/").strip()
SOLC_VERSION = os.getenv("SOLC_VERSION", "0.8.20")

# --- app -------------------------------------------------------------------
HOST = os.getenv("HOST", "127.0.0.1")
PORT = int(os.getenv("PORT", "5000"))
