"""FaceChain - face identification, live web/social search, blockchain verification."""

__version__ = "1.0.0"

from . import config  # noqa: F401

__all__ = ["config"]
