"""The end-to-end pipeline.

    face scan  ->  local index check  ->  live web / social search
               ->  face re-verification of every candidate
               ->  blockchain anchor  ->  re-verification against the chain

Everything the pipeline concludes is written to data/evidence/<id>.json. That
file *is* the record that gets hashed, so it can be re-verified (or shown to
fail after tampering) at any point in the future.
"""
from __future__ import annotations

import base64
import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from . import config, search
from .chain import Blockchain, canonical_json, record_hash
from .face import Face, get_engine, sha256_bytes
from .imghost import publish
from .localdb import LocalFaceDB

Progress = Callable[[str, str, dict], None]


def _noop(step: str, message: str, extra: dict) -> None:
    print(f"  [{step}] {message}")


@dataclass
class ScanResult:
    scan_id: str
    status: str                    # matched | matched_local | not_found | no_face
    message: str
    query_image_sha256: str = ""
    face_hash: str = ""
    faces_detected: int = 0
    query_image_url: str = ""
    identity_guess: str = ""
    candidates: List[dict] = field(default_factory=list)
    match: Optional[dict] = None
    local_match: Optional[dict] = None
    record: Optional[dict] = None
    anchor: Optional[dict] = None
    verification: Optional[dict] = None
    log: List[str] = field(default_factory=list)
    evidence_file: str = ""
    face_thumb_b64: str = ""

    def to_dict(self) -> dict:
        d = self.__dict__.copy()
        return d


class Pipeline:
    def __init__(self, chain_mode: Optional[str] = None, auto_chain: bool = True):
        self.engine = get_engine()
        self.db = LocalFaceDB()
        self.chain: Optional[Blockchain] = None
        self.chain_error: str = ""
        if auto_chain:
            try:
                self.chain = Blockchain(chain_mode)
                self.chain.connect_contract()
            except Exception as exc:  # noqa: BLE001
                self.chain_error = f"{type(exc).__name__}: {exc}"

    # ----------------------------------------------------------------------
    def scan(self, image_bytes: bytes, on_progress: Progress = _noop,
             anchor: bool = True) -> ScanResult:
        scan_id = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
        log: List[str] = []

        def emit(step: str, msg: str, extra: Optional[dict] = None):
            log.append(f"{step}: {msg}")
            on_progress(step, msg, extra or {})

        # -- 1. face detection + encoding ----------------------------------
        emit("face", "Detecting and encoding the face (YuNet + SFace)")
        faces: List[Face] = self.engine.encode_bytes(image_bytes)
        if not faces:
            return ScanResult(scan_id=scan_id, status="no_face",
                              message="No face found in the input image.", log=log)
        face = faces[0]
        img_sha = sha256_bytes(image_bytes)
        fhash = face.face_hash()
        thumb_b64 = base64.b64encode(self.engine.crop_to_png(face)).decode()
        emit("face", f"{len(faces)} face(s) detected - encoded 128-d embedding",
             {"faces": len(faces), "face_hash": fhash})

        result = ScanResult(
            scan_id=scan_id, status="", message="",
            query_image_sha256=img_sha, face_hash=fhash,
            faces_detected=len(faces), log=log, face_thumb_b64=thumb_b64,
        )

        # -- 2. local index first ------------------------------------------
        emit("local", f"Checking the local enrolled-face index ({len(self.db)} entries)")
        entry, score = self.db.search(self.engine, face.embedding)
        if entry is not None:
            result.local_match = {**entry.to_dict(), "similarity": round(score, 4)}
            emit("local", f"Known face: {entry.name} (similarity {score:.3f})")
        else:
            emit("local", "No local match" + (f" (best {score:.3f})" if score else ""))

        # -- 3. publish the frame so search engines can fetch it -----------
        emit("upload", "Publishing the scanned frame to a temporary public URL")
        image_url, hostlog = publish(image_bytes, f"{scan_id}.jpg")
        log.extend(f"upload: {line}" for line in hostlog)
        if not image_url:
            emit("upload", "Could not publish the frame - reverse image search unavailable")
        else:
            result.query_image_url = image_url
            emit("upload", f"Published: {image_url}", {"url": image_url})

        # -- 4a. live reverse image search ---------------------------------
        candidates: List[search.Candidate] = []
        if image_url:
            engines = ", ".join(n for n, _ in search.available_engines())
            emit("search", f"Reverse image search across the live web [{engines}]")
            slog: List[str] = []
            candidates = search.search_by_image(image_url, log=slog)
            log.extend(f"search: {line}" for line in slog)
            emit("search", f"{len(candidates)} candidate pages "
                           f"({sum(1 for c in candidates if c.is_social)} on social media)",
                 {"count": len(candidates)})

        # -- 4b. if Google can name the person, search social media by name -
        if image_url and config.SERPAPI_KEY:
            try:
                guess, alts = search.serpapi_lens_identity(image_url)
            except Exception as exc:  # noqa: BLE001
                guess, alts = "", []
                log.append(f"search: identity lookup failed ({type(exc).__name__})")
            if guess:
                result.identity_guess = guess
                emit("search", f'Google Lens suggests "{guess}" - searching social media by name',
                     {"name": guess})
                try:
                    by_name = search.serpapi_social_by_name(guess)
                except Exception as exc:  # noqa: BLE001
                    by_name = []
                    log.append(f"search: social-by-name failed ({type(exc).__name__})")
                seen = {c.page_url.split("?")[0] for c in candidates}
                added = 0
                for c in by_name:
                    key = c.page_url.split("?")[0]
                    if key in seen:
                        continue
                    if not c.image_url or c.image_url == c.page_url:
                        c.image_url = search.page_image(c.page_url) or ""
                    if not c.image_url:
                        continue
                    seen.add(key)
                    candidates.append(c)
                    added += 1
                emit("search", f"{added} extra profile page(s) found by name",
                     {"count": added})

        # -- 5. verify each candidate with the face encoder ----------------
        best: Optional[search.Candidate] = None
        if candidates:
            emit("verify", "Downloading each candidate image and re-checking the face")
        for cand in candidates:
            try:
                data = search.fetch_image(cand.image_url)
            except Exception as exc:  # noqa: BLE001
                log.append(f"verify: {cand.source} - fetch failed ({type(exc).__name__})")
                continue
            cand.image_sha256 = sha256_bytes(data)
            cfaces = self.engine.encode_bytes(data)
            if not cfaces:
                log.append(f"verify: {cand.source} - no face in candidate image")
                continue
            cand.similarity = max(self.engine.similarity(face.embedding, cf.embedding)
                                  for cf in cfaces)
            cand.verified = cand.similarity >= config.WEB_MATCH_THRESHOLD
            log.append(f"verify: {cand.source} - similarity {cand.similarity:.3f}"
                       f"{' MATCH' if cand.verified else ''}")
            if cand.verified:
                # prefer a confirmed social hit over a confirmed generic web hit,
                # and within each group prefer the strongest similarity
                if best is None or (cand.is_social, cand.similarity) > (best.is_social, best.similarity):
                    best = cand

        candidates.sort(key=lambda c: (-c.similarity, not c.is_social))
        result.candidates = [c.to_dict() for c in candidates]

        # -- 6. conclusion --------------------------------------------------
        if best is not None:
            result.status = "matched"
            result.match = best.to_dict()
            result.message = (f"Matched on {best.source} "
                              f"(similarity {best.similarity:.3f})")
            emit("match", result.message, {"url": best.page_url})
        elif result.local_match:
            result.status = "matched_local"
            result.message = (f"No public post found, but this face is enrolled locally "
                              f"as {result.local_match['name']}.")
            emit("match", result.message)
        else:
            result.status = "not_found"
            result.message = ("This face was not found on any social platform or the "
                              "open web. Use Add Face to enrol it.")
            emit("match", result.message)

        # -- 7. build the evidence record ----------------------------------
        record = self._build_record(result)
        result.record = record

        # -- 8. anchor on chain --------------------------------------------
        if anchor and result.status in ("matched", "matched_local"):
            self._anchor(result, record, emit)
        elif anchor:
            emit("chain", "Nothing verified to anchor yet - enrol the face first")

        self._write_evidence(result)
        return result

    # ----------------------------------------------------------------------
    def _build_record(self, r: ScanResult) -> dict:
        record = {
            "schema": "facechain/v1",
            "kind": "identification" if r.status == "matched" else r.status,
            "scan_id": r.scan_id,
            "created_at": int(time.time()),
            "query": {
                "image_sha256": r.query_image_sha256,
                "face_hash": r.face_hash,
                "faces_detected": r.faces_detected,
                "detector": "YuNet 2023mar",
                "encoder": "SFace 2021dec (128-d, cosine)",
            },
        }
        if r.identity_guess:
            record["identity_guess"] = r.identity_guess
        if r.match:
            m = r.match
            record["matched_post"] = {
                "page_url": m["page_url"],
                "image_url": m["image_url"],
                "image_sha256": m["image_sha256"],
                "platform": m["platform"],
                "source": m["source"],
                "title": m["title"],
                "snippet": m["snippet"],
                "similarity": m["similarity"],
                "found_by": m["engine"],
            }
        if r.local_match:
            lm = r.local_match
            record["local_identity"] = {
                "id": lm["id"], "name": lm["name"],
                "handles": lm["handles"], "links": lm["links"],
                "similarity": lm["similarity"],
            }
        return record

    def _anchor(self, r: ScanResult, record: dict, emit) -> None:
        if self.chain is None:
            emit("chain", f"Blockchain unavailable ({self.chain_error})")
            r.anchor = {"error": self.chain_error}
            return
        try:
            emit("chain", f"Anchoring the finding on the {self.chain.mode} chain")
            receipt = self.chain.anchor(record, r.face_hash)
            r.anchor = receipt.to_dict()
            emit("chain", f"Anchored - tx {receipt.tx_hash[:18]}... in block {receipt.block_number}",
                 r.anchor)
            emit("reverify", "Re-computing the hash from the evidence and checking the chain")
            r.verification = self.chain.verify(record)
            emit("reverify",
                 "VERIFIED - on-chain record matches the evidence"
                 if r.verification["verified"] else "FAILED - no matching record on chain",
                 r.verification)
        except Exception as exc:  # noqa: BLE001
            msg = f"{type(exc).__name__}: {exc}"
            r.anchor = {"error": msg}
            emit("chain", f"Anchoring failed - {msg}")

    def _write_evidence(self, r: ScanResult) -> None:
        path = config.EVIDENCE_DIR / f"{r.scan_id}.json"
        payload = {
            "record": r.record,
            "anchor": r.anchor,
            "verification": r.verification,
            "status": r.status,
            "message": r.message,
            "candidates": r.candidates,
            "log": r.log,
        }
        path.write_text(json.dumps(payload, indent=2, ensure_ascii=False))
        r.evidence_file = str(path)

    # ----------------------------------------------------------------------
    # Add Face
    # ----------------------------------------------------------------------
    def add_face(self, image_bytes: bytes, name: str,
                 handles: Optional[List[str]] = None,
                 links: Optional[List[str]] = None,
                 notes: str = "", anchor: bool = True) -> dict:
        """Enrol a face the internet does not know about, and anchor it."""
        faces = self.engine.encode_bytes(image_bytes)
        if not faces:
            return {"ok": False, "error": "No face found in the image."}
        face = faces[0]
        entry = self.db.add(
            name=name, embedding=face.embedding, face_hash=face.face_hash(),
            image_bytes=image_bytes, image_sha256=sha256_bytes(image_bytes),
            handles=handles, links=links, notes=notes,
        )
        record = {
            "schema": "facechain/v1",
            "kind": "enrollment",
            "created_at": entry.created_at,
            "enrollment": {
                "id": entry.id, "name": entry.name,
                "handles": entry.handles, "links": entry.links,
                "notes": entry.notes,
                "face_hash": entry.face_hash,
                "image_sha256": entry.image_sha256,
            },
        }
        out = {"ok": True, "entry": entry.to_dict(), "record": record}
        if anchor and self.chain is not None:
            try:
                receipt = self.chain.anchor(record, entry.face_hash)
                self.db.attach_anchor(entry.id, receipt.to_dict())
                out["anchor"] = receipt.to_dict()
                out["verification"] = self.chain.verify(record)
                out["entry"] = self.db.get(entry.id).to_dict()
            except Exception as exc:  # noqa: BLE001
                out["anchor"] = {"error": f"{type(exc).__name__}: {exc}"}
        elif anchor:
            out["anchor"] = {"error": self.chain_error or "chain unavailable"}
        path = config.EVIDENCE_DIR / f"enroll-{entry.id}.json"
        path.write_text(json.dumps(out, indent=2, ensure_ascii=False, default=str))
        out["evidence_file"] = str(path)
        return out

    # ----------------------------------------------------------------------
    def reverify_file(self, evidence_path: str) -> dict:
        """Re-verify a stored evidence file against the chain."""
        data = json.loads(open(evidence_path, encoding="utf-8").read())
        record = data.get("record")
        if record is None:
            return {"verified": False, "error": "evidence file has no record"}
        if self.chain is None:
            return {"verified": False, "error": self.chain_error or "chain unavailable"}
        out = self.chain.verify(record)
        out["canonical_json"] = canonical_json(record)
        out["expected_hash"] = "0x" + record_hash(record).hex()
        return out
