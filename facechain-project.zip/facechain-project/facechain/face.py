"""Face detection + face embedding.

Detector : YuNet   (OpenCV Zoo, face_detection_yunet_2023mar)
Encoder  : SFace   (OpenCV Zoo, face_recognition_sface_2021dec) -> 128-d embedding

Both run through OpenCV's DNN module, so there is no dlib / CUDA / heavyweight
framework to install. Similarity is cosine similarity; SFace's published
operating point is 0.363.
"""
from __future__ import annotations

import hashlib
import io
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import cv2
import numpy as np

from . import config


# --------------------------------------------------------------------------
# model download
# --------------------------------------------------------------------------
def ensure_models(verbose: bool = True) -> None:
    """Download the two ONNX models on first run."""
    for path, url, min_size in (
        (config.YUNET_PATH, config.YUNET_URL, 100_000),
        (config.SFACE_PATH, config.SFACE_URL, 1_000_000),
    ):
        if path.exists() and path.stat().st_size > min_size:
            continue
        if verbose:
            print(f"[models] downloading {path.name} ...")
        path.parent.mkdir(parents=True, exist_ok=True)
        req = urllib.request.Request(url, headers={"User-Agent": config.USER_AGENT})
        with urllib.request.urlopen(req, timeout=180) as resp, open(path, "wb") as fh:
            fh.write(resp.read())
        if path.stat().st_size < min_size:
            path.unlink(missing_ok=True)
            raise RuntimeError(f"Download of {path.name} failed (file too small).")
        if verbose:
            print(f"[models] saved {path.name} ({path.stat().st_size/1e6:.1f} MB)")


# --------------------------------------------------------------------------
# data types
# --------------------------------------------------------------------------
@dataclass
class Face:
    bbox: tuple            # (x, y, w, h)
    score: float
    embedding: np.ndarray  # shape (1, 128), float32
    crop: np.ndarray = field(repr=False, default=None)

    @property
    def embedding_hex(self) -> str:
        return self.embedding.astype(np.float32).tobytes().hex()

    def face_hash(self) -> str:
        """Stable commitment to this face.

        Embeddings are L2-normalised and quantised to 3 decimals before
        hashing, so the same photo always yields the same hash while tiny
        floating point noise does not.
        """
        v = self.embedding.reshape(-1).astype(np.float64)
        v = v / (np.linalg.norm(v) + 1e-12)
        q = np.round(v, 3) + 0.0  # kill -0.0
        payload = ",".join(f"{x:.3f}" for x in q).encode()
        return hashlib.sha256(payload).hexdigest()


# --------------------------------------------------------------------------
# engine
# --------------------------------------------------------------------------
class FaceEngine:
    """Thin wrapper around YuNet + SFace."""

    def __init__(self, auto_download: bool = True):
        if auto_download:
            ensure_models()
        self._detector = cv2.FaceDetectorYN.create(
            str(config.YUNET_PATH), "", (320, 320),
            config.DETECT_SCORE_THRESHOLD, 0.3, 5000,
        )
        self._recognizer = cv2.FaceRecognizerSF.create(str(config.SFACE_PATH), "")

    # ---- image helpers ----------------------------------------------------
    @staticmethod
    def decode(image_bytes: bytes) -> Optional[np.ndarray]:
        arr = np.frombuffer(image_bytes, dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        return img

    @staticmethod
    def read(path: str | Path) -> np.ndarray:
        img = cv2.imread(str(path))
        if img is None:
            raise ValueError(f"Could not read image: {path}")
        return img

    # ---- core -------------------------------------------------------------
    def detect(self, img: np.ndarray):
        """Return (working_image, detections, scale_back).

        YuNet is happiest between ~160px and ~1600px on the long side, so the
        image is rescaled first; `scale_back` maps coordinates back to the
        original image.
        """
        if img is None or img.size == 0:
            return None, [], 1.0
        h, w = img.shape[:2]
        scale = 1.0
        if max(h, w) > 1600:
            scale = 1600 / max(h, w)
        elif max(h, w) < 160:
            scale = 160 / max(h, w)
        working = img if scale == 1.0 else cv2.resize(img, (int(w * scale), int(h * scale)))
        wh, ww = working.shape[:2]
        self._detector.setInputSize((ww, wh))
        _, faces = self._detector.detect(working)
        if faces is None:
            return working, [], 1.0 / scale
        return working, list(faces), 1.0 / scale

    def encode(self, img: np.ndarray, max_faces: int = 5) -> List[Face]:
        """Detect every face in `img` and return them, largest first."""
        working, dets, back = self.detect(img)
        out: List[Face] = []
        for f in dets[:max_faces]:
            try:
                aligned = self._recognizer.alignCrop(working, f)
                emb = self._recognizer.feature(aligned)
            except cv2.error:
                continue
            x, y, w, h = (float(v) * back for v in f[:4])
            out.append(Face(bbox=(x, y, w, h), score=float(f[-1]),
                            embedding=emb, crop=aligned))
        out.sort(key=lambda fc: fc.bbox[2] * fc.bbox[3], reverse=True)
        return out

    def encode_bytes(self, image_bytes: bytes) -> List[Face]:
        img = self.decode(image_bytes)
        if img is None:
            return []
        return self.encode(img)

    def similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Cosine similarity between two SFace embeddings (higher = same person)."""
        return float(self._recognizer.match(a, b, cv2.FaceRecognizerSF_FR_COSINE))

    def is_match(self, a: np.ndarray, b: np.ndarray, threshold: float | None = None) -> bool:
        t = config.MATCH_THRESHOLD if threshold is None else threshold
        return self.similarity(a, b) >= t

    # ---- misc -------------------------------------------------------------
    @staticmethod
    def crop_to_png(face: Face) -> bytes:
        ok, buf = cv2.imencode(".png", face.crop)
        return buf.tobytes() if ok else b""

    @staticmethod
    def annotate(img: np.ndarray, faces: List[Face]) -> bytes:
        """Draw boxes on a copy of the image and return it as PNG bytes."""
        vis = img.copy()
        for f in faces:
            x, y, w, h = (int(v) for v in f.bbox)
            cv2.rectangle(vis, (x, y), (x + w, y + h), (0, 220, 120), 2)
        ok, buf = cv2.imencode(".png", vis)
        return buf.tobytes() if ok else b""


_ENGINE: Optional[FaceEngine] = None


def get_engine() -> FaceEngine:
    """Process-wide singleton (loading SFace costs ~1s)."""
    global _ENGINE
    if _ENGINE is None:
        _ENGINE = FaceEngine()
    return _ENGINE


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
