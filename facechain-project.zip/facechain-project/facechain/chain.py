"""Step 3 of the pipeline: anchor the finding on a blockchain and re-verify it.

Three interchangeable back-ends, same Solidity contract in all three:

  CHAIN_MODE=memory   in-process EVM (eth-tester). No node, no keys, no money.
                      State lives for the life of the process.
  CHAIN_MODE=local    JSON-RPC node on your own machine (Hardhat / Anvil /
                      Ganache) at RPC_URL. Persistent across runs.
  CHAIN_MODE=testnet  public testnet (Polygon Amoy by default) using
                      TESTNET_RPC_URL + PRIVATE_KEY. Real explorer links.

Nothing biometric goes on chain — only keccak256 commitments.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any, Optional

from web3 import Web3
from web3.middleware import ExtraDataToPOAMiddleware

from . import config


# --------------------------------------------------------------------------
# canonical hashing
# --------------------------------------------------------------------------
def canonical_json(record: dict) -> str:
    """Deterministic serialisation - the thing that actually gets hashed."""
    return json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def record_hash(record: dict) -> bytes:
    return Web3.keccak(text=canonical_json(record))


def hex_to_bytes32(value: str) -> bytes:
    v = value[2:] if value.startswith("0x") else value
    return bytes.fromhex(v.rjust(64, "0")[:64])


# --------------------------------------------------------------------------
# compilation
# --------------------------------------------------------------------------
def compile_contract(force: bool = False) -> dict:
    """Compile FaceRegistry.sol, caching the artifact in build/."""
    if config.CONTRACT_ARTIFACT.exists() and not force:
        return json.loads(config.CONTRACT_ARTIFACT.read_text())

    import solcx

    version = config.SOLC_VERSION
    installed = [str(v) for v in solcx.get_installed_solc_versions()]
    if version not in installed:
        print(f"[chain] installing solc {version} (one time) ...")
        solcx.install_solc(version)

    source = config.CONTRACT_SOURCE.read_text()
    compiled = solcx.compile_source(
        source,
        output_values=["abi", "bin"],
        solc_version=version,
        optimize=True,
        optimize_runs=200,
    )
    key = next(k for k in compiled if k.endswith(":FaceRegistry"))
    artifact = {
        "contractName": "FaceRegistry",
        "abi": compiled[key]["abi"],
        "bytecode": "0x" + compiled[key]["bin"],
        "solc": version,
    }
    config.CONTRACT_ARTIFACT.write_text(json.dumps(artifact, indent=2))
    return artifact


# --------------------------------------------------------------------------
@dataclass
class AnchorReceipt:
    record_id: int
    record_hash: str
    tx_hash: str
    block_number: int
    chain_id: int
    chain_mode: str
    contract: str
    explorer_url: str = ""
    timestamp: int = 0

    def to_dict(self) -> dict:
        return self.__dict__.copy()


class Blockchain:
    """One object that talks to whichever chain is configured."""

    def __init__(self, mode: Optional[str] = None):
        self.mode = (mode or config.CHAIN_MODE).lower()
        self.artifact = compile_contract()
        self.abi = self.artifact["abi"]
        self.account = None
        self._private_key = None
        self.w3 = self._connect()
        self.chain_id = self.w3.eth.chain_id
        self.contract = None
        self.address: Optional[str] = None

    # ---- connection -------------------------------------------------------
    def _connect(self) -> Web3:
        if self.mode == "memory":
            from web3.providers.eth_tester import EthereumTesterProvider

            w3 = Web3(EthereumTesterProvider())
            self.account = w3.eth.accounts[0]
            return w3

        rpc = config.TESTNET_RPC_URL if self.mode == "testnet" else config.RPC_URL
        w3 = Web3(Web3.HTTPProvider(rpc, request_kwargs={"timeout": 60}))
        w3.middleware_onion.inject(ExtraDataToPOAMiddleware, layer=0)
        if not w3.is_connected():
            raise ConnectionError(
                f"Cannot reach the {self.mode} chain at {rpc}.\n"
                "  local  -> start a node first:  npx hardhat node   (or: anvil / npx ganache)\n"
                "  testnet-> check TESTNET_RPC_URL in your .env"
            )
        if config.PRIVATE_KEY:
            acct = w3.eth.account.from_key(config.PRIVATE_KEY)
            self.account = acct.address
            self._private_key = config.PRIVATE_KEY
        elif w3.eth.accounts:
            self.account = w3.eth.accounts[0]
        else:
            raise RuntimeError("No account available. Set PRIVATE_KEY in your .env.")
        return w3

    # ---- deployment -------------------------------------------------------
    def _deployments(self) -> dict:
        if config.DEPLOYMENTS_FILE.exists():
            return json.loads(config.DEPLOYMENTS_FILE.read_text())
        return {}

    def _save_deployment(self, address: str) -> None:
        data = self._deployments()
        data[f"{self.mode}:{self.chain_id}"] = {
            "address": address,
            "chainId": self.chain_id,
            "mode": self.mode,
            "deployedAt": int(time.time()),
        }
        config.DEPLOYMENTS_FILE.write_text(json.dumps(data, indent=2))

    def connect_contract(self, deploy_if_missing: bool = True) -> str:
        """Attach to an existing deployment, or deploy a fresh one."""
        key = f"{self.mode}:{self.chain_id}"
        entry = self._deployments().get(key)
        if entry:
            addr = Web3.to_checksum_address(entry["address"])
            if self.w3.eth.get_code(addr) not in (b"", "0x", b"0x"):
                self.address = addr
                self.contract = self.w3.eth.contract(address=addr, abi=self.abi)
                return addr
        if not deploy_if_missing:
            raise RuntimeError("FaceRegistry is not deployed on this chain yet.")
        return self.deploy()

    def deploy(self) -> str:
        factory = self.w3.eth.contract(abi=self.abi, bytecode=self.artifact["bytecode"])
        tx_hash = self._send(factory.constructor())
        receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
        addr = receipt.contractAddress
        self.address = addr
        self.contract = self.w3.eth.contract(address=addr, abi=self.abi)
        self._save_deployment(addr)
        return addr

    # ---- transactions -----------------------------------------------------
    def _send(self, fn_call) -> bytes:
        tx: dict[str, Any] = {"from": self.account}
        if self._private_key:
            tx["nonce"] = self.w3.eth.get_transaction_count(self.account)
            tx["chainId"] = self.chain_id
            try:
                tx["gas"] = int(fn_call.estimate_gas({"from": self.account}) * 1.25)
            except Exception:  # noqa: BLE001
                tx["gas"] = 900_000
            try:
                base = self.w3.eth.gas_price
                tx["maxFeePerGas"] = int(base * 2)
                tx["maxPriorityFeePerGas"] = min(int(base), self.w3.to_wei(30, "gwei"))
            except Exception:  # noqa: BLE001
                pass
            built = fn_call.build_transaction(tx)
            signed = self.w3.eth.account.sign_transaction(built, self._private_key)
            raw = getattr(signed, "raw_transaction", None) or signed.rawTransaction
            return self.w3.eth.send_raw_transaction(raw)
        return fn_call.transact(tx)

    # ---- the two operations that matter -----------------------------------
    def anchor(self, record: dict, face_hash_hex: str) -> AnchorReceipt:
        """Write a commitment to the finding on chain."""
        if self.contract is None:
            self.connect_contract()
        rh = record_hash(record)
        fh = hex_to_bytes32(face_hash_hex)
        source_url = str(record.get("matched_post", {}).get("page_url", ""))[:400]
        platform = str(record.get("matched_post", {}).get("platform", record.get("kind", "web")))[:64]

        tx_hash = self._send(self.contract.functions.anchor(rh, fh, source_url, platform))
        receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=300)
        exists, rid, stored = self.contract.functions.verify(rh).call()

        explorer = ""
        if self.mode == "testnet" and config.EXPLORER_TX_URL:
            explorer = config.EXPLORER_TX_URL.rstrip("/") + "/" + tx_hash.hex()

        return AnchorReceipt(
            record_id=int(rid),
            record_hash="0x" + rh.hex(),
            tx_hash=("0x" + tx_hash.hex()) if not tx_hash.hex().startswith("0x") else tx_hash.hex(),
            block_number=int(receipt.blockNumber),
            chain_id=self.chain_id,
            chain_mode=self.mode,
            contract=self.address or "",
            explorer_url=explorer,
            timestamp=int(stored[4]) if exists else int(time.time()),
        )

    def verify(self, record: dict) -> dict:
        """Recompute the hash from the evidence and look it up on chain."""
        if self.contract is None:
            self.connect_contract(deploy_if_missing=False)
        rh = record_hash(record)
        exists, rid, stored = self.contract.functions.verify(rh).call()
        result = {
            "verified": bool(exists),
            "recomputed_hash": "0x" + rh.hex(),
            "chain_mode": self.mode,
            "chain_id": self.chain_id,
            "contract": self.address,
        }
        if exists:
            result.update({
                "record_id": int(rid),
                "on_chain": {
                    "recordHash": "0x" + stored[0].hex(),
                    "faceHash": "0x" + stored[1].hex(),
                    "sourceUrl": stored[2],
                    "platform": stored[3],
                    "timestamp": int(stored[4]),
                    "submitter": stored[5],
                },
            })
        return result

    def total(self) -> int:
        if self.contract is None:
            self.connect_contract()
        return int(self.contract.functions.total().call())

    def info(self) -> dict:
        return {
            "mode": self.mode,
            "chain_id": self.chain_id,
            "account": self.account,
            "contract": self.address,
            "rpc": "in-process (eth-tester)" if self.mode == "memory"
            else (config.TESTNET_RPC_URL if self.mode == "testnet" else config.RPC_URL),
        }
