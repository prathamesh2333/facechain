"""The "Add Face" store.

When a scan finds nothing on the open web, the UI offers an **Add Face**
button. The operator gives the person a name plus whatever profile links they
know, and the face is enrolled here. Every later scan checks this local index
*first*, so a face that the internet does not know about is still identifiable
the second time it is seen — and that enrolment is itself anchored on chain,
so the record of "who added this face, and when" is tamper-evident too.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from . import config


@dataclass
class Enrollment:
    id: str
    name: str
    handles: List[str] = field(default_factory=list)
    links: List[str] = field(default_factory=list)
    notes: str = ""
    created_at: int = 0
    face_hash: str = ""
    image_sha256: str = ""
    image_file: str = ""
    embedding_file: str = ""
    anchor: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return self.__dict__.copy()

    @classmethod
    def from_dict(cls, d: dict) -> "Enrollment":
        known = {k: d.get(k) for k in cls.__dataclass_fields__ if k in d}
        return cls(**known)  # type: ignore[arg-type]


class LocalFaceDB:
    def __init__(self, path=None):
        self.path = path or config.LOCAL_DB_FILE
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._entries: List[Enrollment] = []
        self._load()

    # ---- persistence ------------------------------------------------------
    def _load(self) -> None:
        if self.path.exists():
            raw = json.loads(self.path.read_text() or "[]")
            self._entries = [Enrollment.from_dict(d) for d in raw]

    def _save(self) -> None:
        self.path.write_text(json.dumps([e.to_dict() for e in self._entries], indent=2))

    # ---- api --------------------------------------------------------------
    def __len__(self) -> int:
        return len(self._entries)

    def all(self) -> List[Enrollment]:
        return list(self._entries)

    def get(self, entry_id: str) -> Optional[Enrollment]:
        return next((e for e in self._entries if e.id == entry_id), None)

    def embedding_of(self, entry: Enrollment) -> Optional[np.ndarray]:
        p = config.FACES_DIR / entry.embedding_file
        if not p.exists():
            return None
        return np.load(p)

    def add(self, name: str, embedding: np.ndarray, face_hash: str,
            image_bytes: bytes, image_sha256: str,
            handles: Optional[List[str]] = None,
            links: Optional[List[str]] = None,
            notes: str = "") -> Enrollment:
        entry_id = uuid.uuid4().hex[:12]
        emb_file = f"{entry_id}.npy"
        img_file = f"{entry_id}.jpg"
        np.save(config.FACES_DIR / emb_file, embedding)
        (config.FACES_DIR / img_file).write_bytes(image_bytes)

        entry = Enrollment(
            id=entry_id,
            name=name.strip() or "Unnamed",
            handles=[h.strip() for h in (handles or []) if h.strip()],
            links=[l.strip() for l in (links or []) if l.strip()],
            notes=notes.strip(),
            created_at=int(time.time()),
            face_hash=face_hash,
            image_sha256=image_sha256,
            image_file=img_file,
            embedding_file=emb_file,
        )
        self._entries.append(entry)
        self._save()
        return entry

    def attach_anchor(self, entry_id: str, anchor: dict) -> None:
        e = self.get(entry_id)
        if e:
            e.anchor = anchor
            self._save()

    def search(self, engine, embedding: np.ndarray, threshold: Optional[float] = None):
        """Return (best_entry, best_score) or (None, best_score)."""
        t = config.MATCH_THRESHOLD if threshold is None else threshold
        best, best_score = None, 0.0
        for entry in self._entries:
            known = self.embedding_of(entry)
            if known is None:
                continue
            score = engine.similarity(embedding, known)
            if score > best_score:
                best, best_score = entry, score
        if best is not None and best_score >= t:
            return best, best_score
        return None, best_score
