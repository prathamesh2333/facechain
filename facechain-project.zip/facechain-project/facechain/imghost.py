"""Publish the query image to a short-lived public URL.

Reverse-image-search back-ends (Google Lens via SerpAPI, Yandex, Bing) need a
URL they can fetch, so the scanned frame is uploaded to a throwaway file host
first. Several hosts are tried in order and every returned URL is checked to
make sure it really serves the image bytes before it is used.
"""
from __future__ import annotations

import re
from typing import Callable, Optional

import requests

from . import config

HEADERS = {"User-Agent": config.USER_AGENT}
TIMEOUT = max(config.SEARCH_TIMEOUT, 40)


def _first_url(text: str) -> Optional[str]:
    m = re.search(r'https?://[^\s"\'<>\\]+', text or "")
    return m.group(0) if m else None


# --------------------------------------------------------------------------
def _litterbox(data: bytes, filename: str) -> Optional[str]:
    """Catbox's temporary bucket - 1 hour retention, fast CDN."""
    r = requests.post(
        "https://litterbox.catbox.moe/resources/internals/api.php",
        data={"reqtype": "fileupload", "time": "1h"},
        files={"fileToUpload": (filename, data, "image/jpeg")},
        headers=HEADERS, timeout=TIMEOUT,
    )
    return _first_url(r.text) if r.ok else None


def _x0at(data: bytes, filename: str) -> Optional[str]:
    r = requests.post("https://x0.at",
                      files={"file": (filename, data, "image/jpeg")},
                      headers=HEADERS, timeout=TIMEOUT)
    return _first_url(r.text) if r.ok else None


def _uguu(data: bytes, filename: str) -> Optional[str]:
    r = requests.post("https://uguu.se/upload",
                      files={"files[]": (filename, data, "image/jpeg")},
                      headers=HEADERS, timeout=TIMEOUT)
    if not r.ok:
        return None
    files = (r.json() or {}).get("files") or []
    return files[0].get("url") if files else None


def _catbox(data: bytes, filename: str) -> Optional[str]:
    r = requests.post("https://catbox.moe/user/api.php",
                      data={"reqtype": "fileupload"},
                      files={"fileToUpload": (filename, data, "image/jpeg")},
                      headers=HEADERS, timeout=TIMEOUT)
    return _first_url(r.text) if r.ok else None


def _tmpfiles(data: bytes, filename: str) -> Optional[str]:
    r = requests.post("https://tmpfiles.org/api/v1/upload",
                      files={"file": (filename, data, "image/jpeg")},
                      headers=HEADERS, timeout=TIMEOUT)
    if not r.ok:
        return None
    url = ((r.json() or {}).get("data") or {}).get("url")
    return url.replace("tmpfiles.org/", "tmpfiles.org/dl/") if url else None


PROVIDERS: list[tuple[str, Callable[[bytes, str], Optional[str]]]] = [
    ("litterbox.catbox.moe", _litterbox),
    ("x0.at", _x0at),
    ("uguu.se", _uguu),
    ("catbox.moe", _catbox),
    ("tmpfiles.org", _tmpfiles),
]


def _serves_image(url: str, expected_len: int) -> bool:
    """Make sure the host actually returns image bytes, not an HTML wrapper."""
    try:
        r = requests.get(url, headers=HEADERS, timeout=25, stream=True)
        if not r.ok:
            return False
        ctype = (r.headers.get("content-type") or "").lower()
        head = r.raw.read(2048, decode_content=True)
        r.close()
        looks_like_image = head[:3] == b"\xff\xd8\xff" or head[:8] == b"\x89PNG\r\n\x1a\n" \
            or head[:4] == b"RIFF" or head[:2] == b"BM"
        return ctype.startswith("image/") or looks_like_image
    except Exception:  # noqa: BLE001
        return False


def publish(data: bytes, filename: str = "query.jpg") -> tuple[Optional[str], list[str]]:
    """Upload `data` and return (public_url, log_lines)."""
    log: list[str] = []
    for name, fn in PROVIDERS:
        try:
            url = fn(data, filename)
        except Exception as exc:  # noqa: BLE001 - any host may be down
            log.append(f"{name}: {type(exc).__name__}")
            continue
        if not url:
            log.append(f"{name}: no url returned")
            continue
        if not _serves_image(url, len(data)):
            log.append(f"{name}: url did not serve an image")
            continue
        log.append(f"{name}: ok")
        return url, log
    return None, log
