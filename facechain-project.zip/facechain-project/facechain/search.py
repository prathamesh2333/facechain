"""Step 2 of the pipeline: search the live web/social media for the scanned face.

This is a genuine search, not a lookup table. The scanned frame is published to
a temporary public URL and then pushed through real reverse-image-search
back-ends. Whatever comes back is treated as *unverified candidates* — each
candidate image is downloaded and run back through the face encoder, and only
candidates whose face actually matches the query embedding survive.

Back-ends, tried in order:
  1. SerpAPI  -> Google Lens          (best quality, needs SERPAPI_KEY)
  2. SerpAPI  -> Yandex reverse image (very strong on faces)
  3. SerpAPI  -> Bing reverse image
  4. Free     -> Yandex reverse image (scraped, no key, best effort)
  5. Free     -> Bing visual search   (scraped, no key, best effort)
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Callable, List, Optional
from urllib.parse import urlparse, quote_plus

import requests

from . import config

HEADERS = {"User-Agent": config.USER_AGENT}


# --------------------------------------------------------------------------
@dataclass
class Candidate:
    """One unverified hit returned by a search back-end."""
    title: str
    page_url: str
    image_url: str
    source: str            # human name of the site, e.g. "Instagram"
    platform: str          # normalised key, e.g. "instagram" / "web"
    engine: str            # which back-end produced it
    snippet: str = ""
    is_social: bool = False
    # filled in later by the verification stage
    similarity: float = 0.0
    verified: bool = False
    image_sha256: str = ""
    face_thumb_png: bytes = field(default=b"", repr=False)

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "page_url": self.page_url,
            "image_url": self.image_url,
            "source": self.source,
            "platform": self.platform,
            "engine": self.engine,
            "snippet": self.snippet,
            "is_social": self.is_social,
            "similarity": round(self.similarity, 4),
            "verified": self.verified,
            "image_sha256": self.image_sha256,
        }


def classify(url: str) -> tuple[str, bool]:
    """Map a URL to (platform_key, is_social)."""
    try:
        host = (urlparse(url).hostname or "").lower()
    except Exception:  # noqa: BLE001
        return "web", False
    host = host[4:] if host.startswith("www.") else host
    for domain, key in config.SOCIAL_DOMAINS.items():
        if host == domain or host.endswith("." + domain):
            return key, key not in {"wikipedia", "wikimedia", "github", "medium", "imdb"}
    return "web", False


def _mk(title, page_url, image_url, source, engine, snippet="") -> Optional[Candidate]:
    if not image_url or not page_url:
        return None
    platform, social = classify(page_url)
    return Candidate(
        title=(title or "")[:300],
        page_url=page_url,
        image_url=image_url,
        source=source or (urlparse(page_url).hostname or "web"),
        platform=platform,
        engine=engine,
        snippet=(snippet or "")[:400],
        is_social=social,
    )


# --------------------------------------------------------------------------
# SerpAPI back-ends
# --------------------------------------------------------------------------
def _serpapi(params: dict) -> dict:
    params = {**params, "api_key": config.SERPAPI_KEY}
    r = requests.get("https://serpapi.com/search.json", params=params,
                     headers=HEADERS, timeout=config.SEARCH_TIMEOUT + 30)
    r.raise_for_status()
    return r.json()


def serpapi_google_lens(image_url: str) -> List[Candidate]:
    data = _serpapi({"engine": "google_lens", "url": image_url, "hl": "en", "country": "in"})
    out = []
    for key in ("visual_matches", "image_results", "knowledge_graph"):
        for item in data.get(key, []) or []:
            c = _mk(
                item.get("title"),
                item.get("link"),
                item.get("thumbnail") or item.get("image") or item.get("original"),
                item.get("source"),
                "serpapi:google_lens",
                item.get("snippet", ""),
            )
            if c:
                out.append(c)
    return out


def serpapi_lens_identity(image_url: str) -> tuple[str, List[str]]:
    """Ask Google Lens who this is.

    Returns (best_guess_name, alternative_labels). Lens exposes an entity /
    knowledge-graph block for recognisable people; when it does, that name is
    what we then search social media for by text.
    """
    if not config.SERPAPI_KEY:
        return "", []
    data = _serpapi({"engine": "google_lens", "url": image_url, "hl": "en"})
    names: List[str] = []
    kg = data.get("knowledge_graph") or []
    if isinstance(kg, dict):
        kg = [kg]
    for item in kg:
        if item.get("title"):
            names.append(item["title"])
    for key in ("related_content", "reverse_image_search"):
        block = data.get(key)
        if isinstance(block, dict) and block.get("query"):
            names.append(block["query"])
    if not names:
        # fall back to the most repeated title among the visual matches
        titles = [i.get("title", "") for i in (data.get("visual_matches") or [])][:10]
        common = {}
        for t in titles:
            for token in re.findall(r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b", t):
                common[token] = common.get(token, 0) + 1
        names = [n for n, _ in sorted(common.items(), key=lambda kv: -kv[1])[:2]]
    names = [n for n in dict.fromkeys(names) if n]
    return (names[0] if names else ""), names[1:]


def serpapi_social_by_name(name: str, limit: int = 12) -> List[Candidate]:
    """Google web search restricted to social platforms, for a known name."""
    if not config.SERPAPI_KEY or not name:
        return []
    sites = " OR ".join(f"site:{d}" for d in
                        ("instagram.com", "x.com", "twitter.com", "facebook.com",
                         "linkedin.com", "youtube.com", "threads.net"))
    data = _serpapi({"engine": "google", "q": f'"{name}" ({sites})',
                     "num": limit, "hl": "en"})
    out = []
    for item in data.get("organic_results", []) or []:
        link = item.get("link")
        if not link:
            continue
        thumb = item.get("thumbnail") or (item.get("rich_snippet") or {}).get("top", {}).get("image")
        c = _mk(item.get("title"), link, thumb or link, item.get("source"),
                "serpapi:google_social", item.get("snippet", ""))
        if c:
            out.append(c)
    return out


def page_image(page_url: str) -> Optional[str]:
    """Pull the main image (og:image / twitter:image) out of a page."""
    try:
        r = requests.get(page_url, headers=HEADERS, timeout=config.SEARCH_TIMEOUT)
        if not r.ok:
            return None
        html = r.text[:400_000]
    except Exception:  # noqa: BLE001
        return None
    for pattern in (
        r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)',
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']',
        r'<meta[^>]+name=["\']twitter:image["\'][^>]+content=["\']([^"\']+)',
    ):
        m = re.search(pattern, html, flags=re.I)
        if m:
            return m.group(1).replace("&amp;", "&")
    return None


def serpapi_yandex(image_url: str) -> List[Candidate]:
    data = _serpapi({"engine": "yandex_images", "url": image_url})
    out = []
    for item in (data.get("image_results") or []) + (data.get("similar_images") or []):
        c = _mk(item.get("title"), item.get("link") or item.get("source_url"),
                item.get("thumbnail") or item.get("original"),
                item.get("source"), "serpapi:yandex", item.get("snippet", ""))
        if c:
            out.append(c)
    return out


def serpapi_bing(image_url: str) -> List[Candidate]:
    data = _serpapi({"engine": "bing_images", "imgurl": image_url, "q": ""})
    out = []
    for item in data.get("images_results", []) or []:
        c = _mk(item.get("title"), item.get("link"), item.get("thumbnail") or item.get("original"),
                item.get("source"), "serpapi:bing")
        if c:
            out.append(c)
    return out


# --------------------------------------------------------------------------
# key-free back-ends (best effort; sites change their internals often)
# --------------------------------------------------------------------------
def free_yandex(image_url: str) -> List[Candidate]:
    url = ("https://yandex.com/images/search?rpt=imageview&format=json&cbir_page=similar"
           f"&url={quote_plus(image_url)}")
    r = requests.get(url, headers=HEADERS, timeout=config.SEARCH_TIMEOUT)
    r.raise_for_status()
    out: List[Candidate] = []
    for blob in re.findall(r'data-bem="({.*?})"', r.text, flags=re.S)[:60]:
        try:
            obj = json.loads(blob.replace("&quot;", '"'))
        except Exception:  # noqa: BLE001
            continue
        stack = [obj]
        while stack:
            node = stack.pop()
            if isinstance(node, dict):
                img = node.get("img_href") or node.get("origUrl")
                page = node.get("page_url") or node.get("url")
                if img and page and str(page).startswith("http"):
                    c = _mk(node.get("title") or node.get("alt"), page, img,
                            node.get("domain"), "free:yandex")
                    if c:
                        out.append(c)
                stack.extend(node.values())
            elif isinstance(node, list):
                stack.extend(node)
    return out


def free_bing(image_url: str) -> List[Candidate]:
    url = ("https://www.bing.com/images/search?view=detailv2&iss=sbi&form=SBIVSP"
           f"&q=imgurl:{quote_plus(image_url)}&mediaurl={quote_plus(image_url)}")
    r = requests.get(url, headers=HEADERS, timeout=config.SEARCH_TIMEOUT)
    r.raise_for_status()
    out: List[Candidate] = []
    for blob in re.findall(r'm="({.*?})"', r.text.replace("&quot;", '"'))[:60]:
        try:
            obj = json.loads(blob)
        except Exception:  # noqa: BLE001
            continue
        c = _mk(obj.get("t"), obj.get("purl"), obj.get("murl") or obj.get("turl"),
                obj.get("dt"), "free:bing")
        if c:
            out.append(c)
    return out


# --------------------------------------------------------------------------
def available_engines() -> List[tuple[str, Callable[[str], List[Candidate]]]]:
    engines: List[tuple[str, Callable[[str], List[Candidate]]]] = []
    if config.SERPAPI_KEY:
        engines += [
            ("serpapi:google_lens", serpapi_google_lens),
            ("serpapi:yandex", serpapi_yandex),
            ("serpapi:bing", serpapi_bing),
        ]
    engines += [("free:yandex", free_yandex), ("free:bing", free_bing)]
    return engines


def search_by_image(image_url: str, log: Optional[list] = None,
                    stop_after_social: bool = True) -> List[Candidate]:
    """Run the available reverse-image engines and merge their candidates."""
    log = log if log is not None else []
    seen: set[str] = set()
    merged: List[Candidate] = []

    for name, fn in available_engines():
        try:
            found = fn(image_url)
        except Exception as exc:  # noqa: BLE001 - engines fail all the time
            log.append(f"{name}: FAILED ({type(exc).__name__}: {exc})")
            continue
        added = 0
        for c in found:
            key = c.page_url.split("?")[0]
            if key in seen:
                continue
            seen.add(key)
            merged.append(c)
            added += 1
        log.append(f"{name}: {added} new candidates")
        if stop_after_social and sum(1 for c in merged if c.is_social) >= 8:
            break

    # social results first, then everything else
    merged.sort(key=lambda c: (not c.is_social,))
    return merged[: config.SEARCH_MAX_CANDIDATES]


def fetch_image(url: str, timeout: int | None = None) -> bytes:
    r = requests.get(url, headers=HEADERS,
                     timeout=timeout or config.SEARCH_TIMEOUT, stream=True)
    r.raise_for_status()
    data = b""
    for chunk in r.iter_content(65536):
        data += chunk
        if len(data) > 12_000_000:  # 12 MB guard
            break
    return data
