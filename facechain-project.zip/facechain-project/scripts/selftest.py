#!/usr/bin/env python3
"""End-to-end self test.

Proves every stage of the pipeline works on this machine without depending on
a search API key being in credit:

  1. a face is detected and encoded
  2. two different photos of the same person match, two different people do not
  3. the candidate-verification stage accepts a real matching web image and
     rejects a non-matching one
  4. the finding is anchored on chain and re-verifies
  5. a tampered copy of the same finding fails to verify

Run:  python scripts/selftest.py            (in-process chain)
      python scripts/selftest.py --chain local
"""
from __future__ import annotations

import argparse
import copy
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from facechain import config, search  # noqa: E402
from facechain.face import get_engine, sha256_bytes  # noqa: E402
from facechain.pipeline import Pipeline  # noqa: E402

OK, BAD, DIM, RESET = "\033[92m", "\033[91m", "\033[2m", "\033[0m"
failures = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global failures
    mark = f"{OK}PASS{RESET}" if condition else f"{BAD}FAIL{RESET}"
    if not condition:
        failures += 1
    print(f"  [{mark}] {label}" + (f"  {DIM}{detail}{RESET}" if detail else ""))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--chain", choices=["memory", "local", "testnet"], default=None)
    args = ap.parse_args()

    print("\n== 1. face engine")
    engine = get_engine()
    a = Path("samples/person_a.jpg")
    b = Path("samples/person_a2.jpg")
    c = Path("samples/person_b.jpg")
    for p in (a, b, c):
        if not p.exists():
            print(f"{BAD}missing sample: {p} - run scripts/fetch_samples.py first{RESET}")
            return 1

    fa = engine.encode(engine.read(a))
    fb = engine.encode(engine.read(b))
    fc = engine.encode(engine.read(c))
    check("face detected in person_a.jpg", len(fa) >= 1)
    check("face detected in person_a2.jpg", len(fb) >= 1)
    check("face detected in person_b.jpg", len(fc) >= 1)

    same = engine.similarity(fa[0].embedding, fb[0].embedding)
    diff = engine.similarity(fa[0].embedding, fc[0].embedding)
    check("same person scores above threshold", same >= config.MATCH_THRESHOLD,
          f"similarity={same:.3f} threshold={config.MATCH_THRESHOLD}")
    check("different people score below threshold", diff < config.MATCH_THRESHOLD,
          f"similarity={diff:.3f}")
    check("face hash is stable", fa[0].face_hash() == engine.encode(engine.read(a))[0].face_hash())

    print("\n== 2. candidate verification stage")
    pipe = Pipeline(chain_mode=args.chain)
    cand_ok = search.Candidate(title="matching page", page_url="https://example.com/a",
                               image_url=str(b), source="local", platform="web",
                               engine="selftest")
    data_ok = b.read_bytes()
    cand_ok.image_sha256 = sha256_bytes(data_ok)
    cand_ok.similarity = max(engine.similarity(fa[0].embedding, f.embedding)
                             for f in engine.encode_bytes(data_ok))
    cand_ok.verified = cand_ok.similarity >= config.WEB_MATCH_THRESHOLD
    check("a genuinely matching candidate is accepted", cand_ok.verified,
          f"similarity={cand_ok.similarity:.3f}")

    data_no = c.read_bytes()
    sim_no = max(engine.similarity(fa[0].embedding, f.embedding)
                 for f in engine.encode_bytes(data_no))
    check("a non-matching candidate is rejected", sim_no < config.WEB_MATCH_THRESHOLD,
          f"similarity={sim_no:.3f}")

    print("\n== 3. blockchain anchor + re-verification")
    if pipe.chain is None:
        check("chain reachable", False, pipe.chain_error)
        return 1
    check("chain reachable", True, f"{pipe.chain.mode} chainId {pipe.chain.chain_id}")

    record = {
        "schema": "facechain/v1",
        "kind": "identification",
        "scan_id": "selftest",
        "query": {"image_sha256": sha256_bytes(a.read_bytes()),
                  "face_hash": fa[0].face_hash()},
        "matched_post": {"page_url": cand_ok.page_url, "platform": "web",
                         "image_sha256": cand_ok.image_sha256,
                         "similarity": round(cand_ok.similarity, 4)},
    }
    receipt = pipe.chain.anchor(record, fa[0].face_hash())
    check("finding anchored on chain", bool(receipt.tx_hash),
          f"record #{receipt.record_id} block {receipt.block_number}")
    check("evidence re-verifies against the chain", pipe.chain.verify(record)["verified"],
          receipt.record_hash)

    tampered = copy.deepcopy(record)
    tampered["matched_post"]["page_url"] = "https://example.com/somewhere-else"
    check("tampered evidence fails to verify",
          not pipe.chain.verify(tampered)["verified"])

    print()
    if failures:
        print(f"{BAD}{failures} check(s) failed{RESET}\n")
        return 1
    print(f"{OK}all checks passed{RESET}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
