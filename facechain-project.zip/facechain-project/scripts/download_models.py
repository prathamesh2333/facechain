#!/usr/bin/env python3
"""Download the two ONNX face models up front (they are also fetched lazily)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from facechain.face import ensure_models  # noqa: E402

if __name__ == "__main__":
    ensure_models(verbose=True)
    print("Models ready.")
