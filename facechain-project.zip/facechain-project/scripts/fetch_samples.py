#!/usr/bin/env python3
"""Fetch a few sample faces so the self test can run out of the box.

These are freely-usable placeholder portraits. Replace them with your own
photos for the demo - the pipeline does not care where the image came from.
"""
from __future__ import annotations

import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SAMPLES = ROOT / "samples"
UA = {"User-Agent": "Mozilla/5.0"}

FILES = {
    # two crops of the same portrait -> must match each other
    "person_a.jpg":  "https://randomuser.me/api/portraits/men/32.jpg",
    "person_a2.jpg": "https://randomuser.me/api/portraits/men/32.jpg",
    # a different person -> must not match
    "person_b.jpg":  "https://randomuser.me/api/portraits/women/44.jpg",
    "lena.jpg":      "https://raw.githubusercontent.com/opencv/opencv/4.x/samples/data/lena.jpg",
}


def main() -> int:
    SAMPLES.mkdir(parents=True, exist_ok=True)
    for name, url in FILES.items():
        dest = SAMPLES / name
        if dest.exists() and dest.stat().st_size > 1000:
            print(f"  have {name}")
            continue
        print(f"  fetching {name} ...")
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=60) as r:
            dest.write_bytes(r.read())

    # person_a2 is a mildly re-processed copy, so the match is not a byte-identical
    # cheat: same face, different pixels.
    try:
        import cv2
        img = cv2.imread(str(SAMPLES / "person_a2.jpg"))
        if img is not None:
            h, w = img.shape[:2]
            img = cv2.resize(img[int(h * 0.05):int(h * 0.95), int(w * 0.05):int(w * 0.95)],
                             (w, h))
            img = cv2.convertScaleAbs(img, alpha=1.12, beta=8)
            cv2.imwrite(str(SAMPLES / "person_a2.jpg"), img,
                        [int(cv2.IMWRITE_JPEG_QUALITY), 82])
    except Exception as exc:  # noqa: BLE001
        print(f"  (could not re-process person_a2: {exc})")

    print("Samples ready in samples/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
