# Running a persistent local chain

`CHAIN_MODE=memory` needs nothing at all, but its state disappears when the
process exits. For a chain that survives between runs (so you can anchor today
and re-verify tomorrow), start any local Ethereum node and use
`CHAIN_MODE=local`.

Pick whichever you already have. All of them listen on `http://127.0.0.1:8545`,
which is what `RPC_URL` defaults to.

## Option A — Hardhat (recommended, cross-platform)

```bash
npm install            # installs hardhat from package.json
npx hardhat node       # leave this running in its own terminal
```

## Option B — Ganache (single command, no project files)

```bash
npx ganache --port 8545
```

## Option C — Anvil (Foundry)

```bash
anvil
```

## Then, in another terminal

```bash
# .env  ->  CHAIN_MODE=local
python run.py deploy
python run.py scan samples/your_face.jpg
python run.py verify data/evidence/<the-file>.json
```

All three nodes unlock funded dev accounts automatically, so you do not need a
`PRIVATE_KEY` for local mode.
