// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title FaceRegistry
 * @notice Tamper-evident registry for face-identification findings.
 *
 * The pipeline never stores raw biometric data or raw post content on chain.
 * It stores only cryptographic commitments:
 *
 *   recordHash  keccak256 of the canonical JSON of the whole finding
 *               (query image hash, matched post URL, post image hash,
 *                post text, platform, similarity score, timestamp...)
 *   faceHash    keccak256 of the quantised face embedding of the query face,
 *               so every finding about the same person can be listed later.
 *
 * Re-verification = recompute recordHash off chain from the stored evidence
 * file and ask verify() whether that exact hash was anchored. If a single
 * byte of the evidence changed, the hash changes and verification fails.
 */
contract FaceRegistry {
    struct Record {
        bytes32 recordHash;   // commitment to the full finding
        bytes32 faceHash;     // commitment to the face embedding
        string sourceUrl;     // URL of the matched social/web post
        string platform;      // "instagram", "x", "linkedin", "web", "enrollment"...
        uint64 timestamp;     // block timestamp of anchoring
        address submitter;    // who anchored it
    }

    Record[] private _records;

    // recordHash => id + 1 (0 means "not anchored")
    mapping(bytes32 => uint256) private _indexOfHash;

    // faceHash => list of record ids
    mapping(bytes32 => uint256[]) private _byFace;

    event RecordAnchored(
        uint256 indexed id,
        bytes32 indexed recordHash,
        bytes32 indexed faceHash,
        string sourceUrl,
        string platform,
        address submitter,
        uint64 timestamp
    );

    error EmptyHash();
    error AlreadyAnchored(uint256 existingId);
    error UnknownRecord();

    /// @notice Anchor a new finding. Reverts if this exact record was already anchored.
    function anchor(
        bytes32 recordHash,
        bytes32 faceHash,
        string calldata sourceUrl,
        string calldata platform
    ) external returns (uint256 id) {
        if (recordHash == bytes32(0)) revert EmptyHash();
        uint256 existing = _indexOfHash[recordHash];
        if (existing != 0) revert AlreadyAnchored(existing - 1);

        _records.push(
            Record({
                recordHash: recordHash,
                faceHash: faceHash,
                sourceUrl: sourceUrl,
                platform: platform,
                timestamp: uint64(block.timestamp),
                submitter: msg.sender
            })
        );

        id = _records.length - 1;
        _indexOfHash[recordHash] = _records.length;
        _byFace[faceHash].push(id);

        emit RecordAnchored(id, recordHash, faceHash, sourceUrl, platform, msg.sender, uint64(block.timestamp));
    }

    /// @notice Check whether a recomputed record hash matches something on chain.
    function verify(bytes32 recordHash)
        external
        view
        returns (bool exists, uint256 id, Record memory record)
    {
        uint256 slot = _indexOfHash[recordHash];
        if (slot == 0) {
            return (false, 0, record);
        }
        id = slot - 1;
        return (true, id, _records[id]);
    }

    function getRecord(uint256 id) external view returns (Record memory) {
        if (id >= _records.length) revert UnknownRecord();
        return _records[id];
    }

    function total() external view returns (uint256) {
        return _records.length;
    }

    function recordsForFace(bytes32 faceHash) external view returns (uint256[] memory) {
        return _byFace[faceHash];
    }
}
